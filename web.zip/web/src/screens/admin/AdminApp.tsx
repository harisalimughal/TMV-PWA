import React, { useEffect, useRef, useState } from "react";
import { Loader2 } from "lucide-react";
import { adminLogout, fetchAdminSession } from "../../api/admin";
import { AdminLoginScreen } from "./AdminLoginScreen";
import { Layout } from "./dashboard/Layout";
import { OverviewPage } from "./dashboard/pages/OverviewPage";
import { LiveFleetPage } from "./dashboard/pages/LiveFleetPage";
import { JobsPage } from "./dashboard/pages/JobsPage";
import { VanMileagePage } from "./dashboard/pages/VanMileagePage";
import { FinishedJobsPage } from "./dashboard/pages/FinishedJobsPage";
import { NotificationsAlertsPage } from "./dashboard/pages/NotificationsAlertsPage";
import { DriversPage } from "./dashboard/pages/DriversPage";
import { DriverReportPage } from "./dashboard/pages/DriverReportPage";
import { LiabilityPage, LIABILITY_SECTIONS } from "./dashboard/pages/LiabilityPage";
import { ConfigurationsPage, CONFIGURATION_SECTIONS } from "./dashboard/pages/ConfigurationsPage";
import { MaintenancePage } from "./dashboard/pages/MaintenancePage";
import { usePushNotifications } from "../../lib/pwa/usePushNotifications";
import { useServiceWorkerUpdate } from "../pwa-settings/hooks/useServiceWorkerUpdate";

/**
 * Entry point for the /admin path on dashboard.themanvan.co.uk (see App.tsx's
 * hostname+pathname check). Fully independent of the driver login flow -- its own
 * session cookie (tmv_admin_session), its own password, mounted at /api/admin.
 *
 * The bulk of this -- Layout + all 13 pages -- is TMV-Chat-bot's dashboard/web ported
 * into tmv-pwa (see ./dashboard/*), so this domain can run entirely off tmv-pwa's own
 * Mongo backend instead of the retired Sheets/Drive-dependent project.
 */
export function AdminApp() {
  const [checking, setChecking] = useState(true);
  const [loggedIn, setLoggedIn] = useState(false);
  const [activeSection, setActiveSection] = useState<string>("overview");

  useEffect(() => {
    fetchAdminSession()
      .then(setLoggedIn)
      .finally(() => setChecking(false));
  }, []);

  // The dashboard is a desktop ops tool, not an offline PWA -- when a new build ships
  // there is no value in a "refresh available?" prompt (that's the driver app's
  // UpdateBanner). Apply a waiting service-worker update automatically so a deploy
  // lands within a poll cycle instead of being stuck behind the cache until every tab
  // is closed. The reload is loop-guarded in the registration singleton; the short
  // delay lets React settle first.
  const { needRefresh, applyUpdate } = useServiceWorkerUpdate();
  useEffect(() => {
    if (!needRefresh) return;
    const t = setTimeout(() => void applyUpdate(), 2000);
    return () => clearTimeout(t);
  }, [needRefresh, applyUpdate]);

  // Same auto-prompt as the driver app's App.tsx: fires the browser's own "Allow
  // notifications?" dialog right on login instead of leaving it for the admin to find
  // in Pricing Settings themselves. It can only ever prompt, not silently subscribe --
  // that's a hard browser rule, not something either app can work around -- but this
  // removes the settings-hunt before that prompt appears. Fires at most once per app
  // load, only while permission is still "default" (never decided); a denied prompt is
  // never retried here (the browser blocks JS from re-showing it after a denial).
  const { permission: pushPermission, isSupported: pushSupported, subscribe: subscribeToPush } =
    usePushNotifications();
  const autoPushPromptedRef = useRef(false);
  useEffect(() => {
    if (!loggedIn) return;
    if (autoPushPromptedRef.current) return;
    if (!pushSupported || pushPermission !== "default") return;
    autoPushPromptedRef.current = true;
    const timer = setTimeout(() => void subscribeToPush(), 1200);
    return () => clearTimeout(timer);
  }, [loggedIn, pushSupported, pushPermission, subscribeToPush]);

  /**
   * Section state lives in ?section=. pushState was already being called on every
   * change, but nothing listened for popstate -- so the browser's Back button changed
   * the URL and left the UI on the same page, which is worse than not pushing history
   * at all. This listener closes that loop.
   */
  useEffect(() => {
    const readSection = () => {
      const params = new URLSearchParams(window.location.search);
      const sec = params.get("section");
      const job = params.get("job");
      if (!sec && job) {
        setActiveSection("jobs");
        return;
      }
      setActiveSection(LIABILITY_SECTIONS.includes(sec || "") ? "liabilities" : sec === "alerts" ? "notifications" : CONFIGURATION_SECTIONS.includes(sec || "") ? "configurations" : sec || "overview");
    };
    readSection();
    window.addEventListener("popstate", readSection);
    return () => window.removeEventListener("popstate", readSection);
  }, []);

  function handleSelectSection(section: string) {
    if (section === activeSection) return; // don't stack duplicate history entries
    setActiveSection(LIABILITY_SECTIONS.includes(section) ? "liabilities" : section === "alerts" ? "notifications" : CONFIGURATION_SECTIONS.includes(section) ? "configurations" : section);
    const url = new URL(window.location.href);
    url.searchParams.set("section", section);
    if (section === "notifications") url.searchParams.delete("notificationsTab");
    if (section === "configurations") url.searchParams.delete("configurationTab");
    url.searchParams.delete("reportReturn");
    window.history.pushState({ section }, "", url.toString());
    window.dispatchEvent(new PopStateEvent("popstate"));
  }

  async function handleLogout() {
    try {
      await adminLogout();
    } finally {
      setLoggedIn(false);
    }
  }

  if (checking) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-admin-bg">
        <Loader2 className="w-6 h-6 animate-spin text-admin-muted" />
      </div>
    );
  }

  if (!loggedIn) {
    return <AdminLoginScreen onLoggedIn={() => setLoggedIn(true)} />;
  }

  return (
    <Layout activeSection={activeSection} onSelectSection={handleSelectSection} onLogout={handleLogout}>
      {activeSection === "overview" && <OverviewPage onSelectSection={handleSelectSection} />}
      {activeSection === "livefleet" && <LiveFleetPage onSelectSection={handleSelectSection} />}
      {activeSection === "jobs" && <JobsPage />}
      {activeSection === "van" && <VanMileagePage />}
      {activeSection === "finished" && <JobsPage initialStatus="Finished" />}
      {activeSection === "notifications" && <NotificationsAlertsPage />}
      {activeSection === "liabilities" && <LiabilityPage />}
      {activeSection === "drivers" && <DriversPage />}
      {activeSection === "driverreport" && <DriverReportPage />}
      {activeSection === "configurations" && <ConfigurationsPage />}
      {activeSection === "maintenance" && <MaintenancePage />}
    </Layout>
  );
}
