import React, { useState } from "react";
import { driverReportHref, navigateAdmin, retainRangeInUrl } from "../utils/reportNavigation";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { deleteDriver, fetchDrivers, saveDriver } from "../api";
import {
  Plus,
  ShieldCheck,
  Mail,
  Phone,
  Truck,
  Edit3,
  Trash2,
  UserX
} from "lucide-react";
import { getAvatarColor, formatVanReg } from "../utils/drivers";
import { AddDriverModal } from "../components/AddDriverModal";
import { ApiErrorState } from "../components/ApiErrorState";
import { DateRangePicker, defaultDashboardDateRange } from "../components/DateRangePicker";
import { AdminFilterBar } from "../components/AdminFilterBar";
import { DriverSummaryItem } from "../types";
import { Button } from "../../../../ui";
import { formatDuration } from "../utils/kpi";
import { DRIVER_OPTIONS_QUERY_KEY } from "../hooks/useDriverOptions";

export function DriversPage() {
  const queryClient = useQueryClient();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingDriver, setEditingDriver] = useState<DriverSummaryItem | null>(null);
  const [from, setFrom] = useState<string | undefined>(() => new URLSearchParams(window.location.search).get("from") || defaultDashboardDateRange().from);
  const [to, setTo] = useState<string | undefined>(() => new URLSearchParams(window.location.search).get("to") || defaultDashboardDateRange().to);

  // Real roster + real per-driver stats (assigned/completed/revenue/missing evidence,
  // avg delay/duration) -- all computed server-side against actual job data, not the
  // old localStorage-backed roster + a re-aggregation of fetchJobs() here. from/to
  // scope every one of those stats server-side (drivers-summary.routes.ts), the same
  // way Finished Jobs' own date filter scopes its results.
  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: ["drivers_summary", from, to],
    queryFn: () => fetchDrivers(from, to),
    staleTime: 30000
  });

  const allDrivers = data?.drivers ?? [];
  // hasAccount is false for a code that only shows up because some job's
  // driverInitials matches it -- e.g. typed straight into a Calendar title -- with
  // nobody ever added via Add Driver. Those jobs stay assigned exactly as they are;
  // this only keeps a driver-less initials code from cluttering the roster with a
  // card that has no account behind it to edit, deactivate or delete. If a real
  // driver is later added with the same initials, this same job then folds into
  // their real card automatically (drivers-summary.routes.ts groups by initials).
  const roster = allDrivers.filter(d => d.initials !== "UNASSIGNED" && d.hasAccount);

  const handleDeactivate = async (driver: DriverSummaryItem) => {
    if (!driver.email) return;
    if (!window.confirm(`Are you sure you want to deactivate ${driver.fullName}? They will be blocked from the app.`)) return;
    await saveDriver({
      initials: driver.initials,
      fullName: driver.fullName,
      email: driver.email,
      phone: driver.phone,
      vanRegistration: driver.vanRegistration,
      active: false
    });
    queryClient.invalidateQueries({ queryKey: ["drivers_summary"] });
    queryClient.invalidateQueries({ queryKey: DRIVER_OPTIONS_QUERY_KEY });
  };

  const handleDelete = async (driver: DriverSummaryItem) => {
    if (!driver.email) return;
    if (
      !window.confirm(
        `Permanently delete ${driver.fullName}? This cannot be undone -- unlike Deactivate, there is no way to restore this driver afterwards. Their past jobs keep the "${driver.initials}" initials but will no longer show a name, email or phone.`
      )
    ) {
      return;
    }
    try {
      await deleteDriver(driver.email);
      queryClient.invalidateQueries({ queryKey: ["drivers_summary"] });
      queryClient.invalidateQueries({ queryKey: DRIVER_OPTIONS_QUERY_KEY });
    } catch (err: any) {
      window.alert(err?.message || "Failed to delete driver.");
    }
  };

  return (
    <div className="space-y-6 max-w-[1440px] mx-auto pb-12">
      <div className="flex items-center justify-between px-2">
        <div>
          <p className="text-[13px] text-admin-muted mt-0.5">
            {isLoading ? "..." : `${roster.filter(d => d.active).length} active drivers`}
          </p>
        </div>
        <Button onClick={() => setIsAddModalOpen(true)} iconLeft={<Plus />}>
          Add driver
        </Button>
      </div>

      {/* TOOLBAR -- scopes every card's Completed Jobs/Revenue/Total Move Time (and
          Avg Start Delay) to this range server-side, same as Finished Jobs' filter. */}
      <AdminFilterBar dates={<DateRangePicker from={from} to={to} onChange={(f, t) => { setFrom(f); setTo(t); retainRangeInUrl(f, t); }} />} />

      {isLoading && (
        <div className="h-64 bg-white rounded-[6px] border border-admin-line animate-pulse flex items-center justify-center">
          <span className="text-admin-muted font-medium">Loading drivers...</span>
        </div>
      )}

      {!isLoading && isError && (
        <ApiErrorState message={(error as Error)?.message} onRetry={() => refetch()} />
      )}

      {!isLoading && !isError && roster.length === 0 && (
        <div className="h-64 bg-white rounded-[6px] border border-admin-line flex items-center justify-center">
          <span className="text-admin-muted font-medium">No drivers to show.</span>
        </div>
      )}

      {/* DRIVER CARDS GRID */}
      {!isLoading && !isError && roster.length > 0 && (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 items-stretch">
        {roster.map((driver) => (
          <div
            key={driver.initials}
            onClick={event => { if ((event.target as Element).closest("button,a,input,select")) return; navigateAdmin(driverReportHref(driver.initials, from, to)); }}
            className="bg-white rounded-[6px] border border-admin-line p-6 flex flex-col justify-between hover:border-admin-brand/40 transition-colors cursor-pointer relative group"
          >
            {/* Header Row */}
            <div className="flex items-start justify-between gap-3 mb-4">
              <div className="flex min-w-0 items-center gap-3">
                <div className={`w-10 h-10 shrink-0 rounded-full flex items-center justify-center font-bold text-[14px] ${getAvatarColor(driver.initials)}`}>
                  {driver.initials}
                </div>
                <div className="min-w-0">
                  <h3 className="font-bold text-admin-ink text-[16px] flex items-center gap-1.5 leading-tight">
                    <button className="text-left truncate focus-visible:outline focus-visible:outline-2" onClick={event => { event.stopPropagation(); navigateAdmin(driverReportHref(driver.initials, from, to)); }} title={`Open report for ${driver.fullName}`}>{driver.fullName}</button>
                    {driver.active && (
                      <span title="Verified Active" className="cursor-help shrink-0">
                        <ShieldCheck className="w-4 h-4 text-[#10b981]" />
                      </span>
                    )}
                  </h3>
                </div>
              </div>

              <div className="flex shrink-0 flex-col items-end gap-2">
                <span className={`px-2 py-0.5 rounded-control text-[11px] font-bold uppercase tracking-wider ${
                  driver.active ? "bg-admin-status-green-bg text-admin-status-green" : "bg-admin-surface text-admin-muted"
                }`}>
                  {driver.active ? "Active" : "Inactive"}
                </span>

                {/* Overflow menu triggers. Hover-reveal only from md up -- below that
                    (this card grid's single-column mobile layout) touch has no real
                    hover, so a tap would just trigger the hover state instead of the
                    button underneath it; always visible there instead. */}
                <div className="flex items-center gap-1 opacity-100 transition md:opacity-0 md:group-hover:opacity-100">
                  <button
                    onClick={(e) => { e.stopPropagation(); setEditingDriver(driver); }}
                    title="Edit Driver"
                    className="p-1 rounded-full text-admin-muted hover:bg-admin-brand hover:text-white transition"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={(e) => { e.stopPropagation(); handleDeactivate(driver); }}
                    title="Deactivate Driver"
                    className="p-1 rounded-full text-admin-muted hover:bg-admin-status-red hover:text-white transition"
                  >
                    <UserX className="w-4 h-4" />
                  </button>
                  <button
                    onClick={(e) => { e.stopPropagation(); handleDelete(driver); }}
                    title="Delete Driver Permanently"
                    className="p-1 rounded-full text-admin-muted hover:bg-admin-status-red hover:text-white transition"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Contact / Van Reg Line */}
            <div className="flex flex-col gap-2 mb-6 text-[13px] text-admin-muted">
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5">
                <span className="flex min-w-0 items-center gap-1.5"><Mail className="w-3.5 h-3.5 shrink-0" /> <span className="truncate">{driver.email || "—"}</span></span>
                <span className="flex min-w-0 items-center gap-1.5"><Phone className="w-3.5 h-3.5 shrink-0" /> <span className="truncate">{driver.phone || "—"}</span></span>
              </div>
              {driver.vanRegistration && (
                <div className="flex items-center gap-1.5 mt-1">
                  <Truck className="w-4 h-4 text-admin-ink-2" />
                  <span className="px-2 py-1 rounded-control border border-admin-line bg-admin-surface font-mono font-bold text-admin-ink tracking-widest text-[12px] shadow-sm uppercase">
                    {formatVanReg(driver.vanRegistration)}
                  </span>
                </div>
              )}
            </div>

            {/* Stats Grid 2x2 */}
            <div className="grid grid-cols-2 gap-x-4 gap-y-5">
              <div>
                <span className="text-admin-muted block text-[12px] mb-1">Completed Jobs</span>
                <div className="flex items-baseline gap-2">
                  <span className="font-bold text-admin-ink text-[18px] tabular-nums leading-none">
                    {driver.completed}
                  </span>
                </div>
              </div>

              <div>
                <span className="text-admin-muted block text-[12px] mb-1">Revenue Handled</span>
                <span className="font-bold text-admin-ink text-[18px] tabular-nums leading-none block">
                  {driver.revenueFormatted}
                </span>
                <span className="text-[11px] text-admin-muted font-medium mt-1.5 block tracking-wide">
                  £{driver.cashCollectedPounds.toFixed(2)} CASH · £{driver.cardCollectedPounds.toFixed(2)} CARD
                </span>
              </div>

              <div>
                <span className="text-admin-muted block text-[12px] mb-1">Avg Start Delay</span>
                <span className={`font-bold text-[16px] tabular-nums leading-none block ${driver.avgDelayMinutes > 15 ? 'text-admin-status-red' : 'text-admin-status-green'}`}>
                  +{driver.avgDelayMinutes} mins
                </span>
              </div>

              <div>
                <span className="text-admin-muted block text-[12px] mb-1">Total Move Time</span>
                <span className="font-bold text-admin-ink text-[16px] tabular-nums leading-none block">
                  {formatDuration(driver.totalDurationMinutes)}
                </span>
              </div>

              <div className="col-span-2 border-t border-admin-line pt-4">
                <span className="text-admin-muted block text-[12px] mb-1">Review Reports</span>
                <span className="font-bold text-admin-ink text-[15px] tabular-nums">
                  {driver.reviewSentCount} sent
                </span>
                <span className="text-admin-muted text-[13px] tabular-nums"> · {driver.reviewNotSentCount} not sent</span>
              </div>
            </div>
          </div>
        ))}
      </div>
      )}

      <AddDriverModal
        isOpen={isAddModalOpen || !!editingDriver}
        onClose={() => { setIsAddModalOpen(false); setEditingDriver(null); }}
        driverToEdit={editingDriver}
      />
    </div>
  );
}
