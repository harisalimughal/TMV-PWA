import React, { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { X, AlertTriangle, CheckCircle2 } from "lucide-react";
import { fetchDrivers, fetchLiveFleet, saveDriver } from "../api";
import { DriverSummaryItem } from "../types";
import { Button, IconButton } from "../../../../ui";
import { DRIVER_OPTIONS_QUERY_KEY } from "../hooks/useDriverOptions";

interface Props {
  isOpen: boolean;
  onClose: () => void;
  driverToEdit?: DriverSummaryItem | null;
}

export function AddDriverModal({ isOpen, onClose, driverToEdit }: Props) {
  const queryClient = useQueryClient();
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [vehicleReg, setVehicleReg] = useState("");
  const [imei, setImei] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [active, setActive] = useState(true);
  const [pwaPassword, setPwaPassword] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [saveError, setSaveError] = useState("");
  const [saveWarning, setSaveWarning] = useState("");

  // Driver summary includes account-backed roster rows plus job-only initials rows.
  // Only a real account can own/block a code; job-only rows are allowed to be folded
  // into the newly-created driver account with the same initials.
  const { data: driversData } = useQuery({ queryKey: ["drivers_summary"], queryFn: () => fetchDrivers() });
  const roster = driversData?.drivers ?? [];

  // A picker rather than a free-text box: a wrong digit in a 15-digit IMEI is silent
  // and effectively unrecoverable (the whole point of using IMEI over a plate is to
  // avoid exactly that kind of typo), so this only ever offers real, currently-known
  // GPSLive devices. Only fetched while the modal is open.
  const { data: fleetData } = useQuery({
    queryKey: ["fleet_live"],
    queryFn: fetchLiveFleet,
    enabled: isOpen
  });
  const devices = fleetData?.vehicles ?? [];

  // Sync state with driverToEdit when modal opens or driver changes
  useEffect(() => {
    if (driverToEdit) {
      setName(driverToEdit.fullName);
      setCode(driverToEdit.initials);
      setVehicleReg(driverToEdit.vanRegistration || "");
      setImei(driverToEdit.imei || "");
      setEmail(driverToEdit.email || "");
      setPhone(driverToEdit.phone || "");
      setActive(driverToEdit.active !== false);
    } else {
      setName("");
      setCode("");
      setVehicleReg("");
      setImei("");
      setEmail("");
      setPhone("");
      setActive(true);
    }
    setPwaPassword("");
    setSaveError("");
    setSaveWarning("");
  }, [driverToEdit, isOpen]);

  if (!isOpen) return null;

  const handleNameChange = (val: string) => {
    setName(val);
    if (!driverToEdit && (!code || code.length < 2)) {
      setCode(val.substring(0, 2).toUpperCase());
    }
  };

  // Initials are taken if a real driver account owns them AND we aren't editing that
  // same driver. Job-only summary rows must not block creating the account.
  const isCodeTaken = roster.some(d =>
    d.hasAccount && d.initials === code.toUpperCase() && (!driverToEdit || driverToEdit.initials !== code.toUpperCase())
  );
  const passwordTooShort = pwaPassword.length > 0 && pwaPassword.length < 8;

  const handleSubmit = async () => {
    setSaveError("");
    setSaveWarning("");
    setIsSaving(true);
    try {
      const initials = code.toUpperCase();
      const result = await saveDriver({
        initials,
        fullName: name,
        email,
        active,
        phone,
        vanRegistration: vehicleReg,
        imei,
        // Omitted (not sent empty) when blank, so editing a driver without touching
        // this field never resets/clears their existing app password.
        ...(pwaPassword ? { password: pwaPassword } : {})
      });

      // The save itself is fast -- it only touches driver_accounts. What's slow is
      // /api/admin/drivers/summary's own refetch, since it also recomputes every
      // driver's job stats from the full dataset (jobs/evidence/activity/...), which
      // can take several seconds regardless of what actually changed here. Patch the
      // fields we just saved into the cache directly so the roster reflects the edit
      // immediately instead of the UI sitting on stale data until that slow refetch
      // lands -- invalidateQueries below still runs in the background to pick up
      // anything the optimistic patch can't know (e.g. a brand-new driver's real
      // job stats), it just no longer blocks what the admin sees right now.
      // setQueriesData (not setQueryData) -- DriversPage.tsx's own query key is
      // ["drivers_summary", from, to] (it has its own date-range filter), not the bare
      // ["drivers_summary"] every other caller here uses. A single-key setQueryData
      // would miss it entirely, patching everywhere except the one page an admin is
      // actually looking at while editing.
      queryClient.setQueriesData<{ drivers: DriverSummaryItem[] } | undefined>({ queryKey: ["drivers_summary"] }, old => {
        if (!old?.drivers) return old;
        const patch: Partial<DriverSummaryItem> = {
          initials, fullName: name, email, phone, vanRegistration: vehicleReg, imei, active, hasAccount: true
        };
        const idx = old.drivers.findIndex(d => d.hasAccount && d.initials === initials);
        if (idx >= 0) {
          const drivers = [...old.drivers];
          drivers[idx] = { ...drivers[idx], ...patch };
          return { ...old, drivers };
        }
        // Brand-new driver: seed zeroed stats so it shows up right away; the
        // background refetch fills in real numbers once it lands.
        return {
          ...old,
          drivers: [
            ...old.drivers,
            {
              ...patch,
              assigned: 0, completed: 0, cancelled: 0, completionRate: 0,
              avgDurationMinutes: 0, avgDelayMinutes: 0, revenuePounds: 0, revenueFormatted: "£0.00",
              cashCollectedPounds: 0, missingEvidenceCount: 0, overtimeCount: 0
            } as DriverSummaryItem
          ]
        };
      });
      queryClient.invalidateQueries({ queryKey: ["drivers_summary"] });
      queryClient.invalidateQueries({ queryKey: DRIVER_OPTIONS_QUERY_KEY });
      if (result.warning) {
        // Stay open so the warning is actually seen -- the Sheets save did succeed,
        // this isn't a failure, but silently closing would hide that the password
        // part didn't take.
        setSaveWarning(result.warning);
      } else {
        onClose();
      }
    } catch (err: any) {
      setSaveError(err?.message || "Failed to save driver.");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-white rounded-module shadow-2xl w-full max-w-[500px] max-h-[90vh] flex flex-col overflow-hidden">
        <div className="px-6 py-5 border-b border-admin-line flex items-center justify-between shrink-0">
          <h2 className="text-title text-fg">{driverToEdit ? "Edit Driver" : "Add New Driver"}</h2>
          <IconButton aria-label="Close" icon={<X />} onClick={onClose} className="-mr-2" />
        </div>

        <div className="p-6 space-y-5 overflow-y-auto custom-scrollbar">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="block text-eyebrow text-fg-subtle tracking-wider mb-1.5">Full Name <span className="text-admin-status-red">*</span></label>
              <input 
                type="text" 
                value={name}
                onChange={e => handleNameChange(e.target.value)}
                className="w-full h-11 px-3 rounded-card border border-admin-line bg-admin-surface text-[14px] text-admin-ink outline-none focus:border-admin-brand focus:bg-white transition"
                placeholder="e.g. John Doe"
              />
            </div>
            
            <div>
              <label className="block text-eyebrow text-fg-subtle tracking-wider mb-1.5">Driver Code (2-letter) <span className="text-admin-status-red">*</span></label>
              <input 
                type="text" 
                maxLength={2}
                value={code}
                onChange={e => setCode(e.target.value.toUpperCase())}
                className={`w-full h-11 px-3 rounded-card border ${isCodeTaken ? 'border-admin-status-red focus:border-admin-status-red' : 'border-admin-line focus:border-admin-brand'} bg-admin-surface text-[14px] text-admin-ink outline-none focus:bg-white transition uppercase`}
                placeholder="e.g. JD"
              />
              {isCodeTaken && <span className="text-[11px] text-admin-status-red mt-1 block">This code is already in use.</span>}
            </div>

            <div>
              <label className="block text-eyebrow text-fg-subtle tracking-wider mb-1.5">Vehicle Registration</label>
              <input
                type="text"
                value={vehicleReg}
                onChange={e => setVehicleReg(e.target.value.toUpperCase())}
                className="w-full h-11 px-3 rounded-card border border-admin-line bg-admin-surface text-[14px] font-mono text-admin-ink outline-none focus:border-admin-brand focus:bg-white transition uppercase"
                placeholder="e.g. AB12 CDE"
              />
            </div>

            <div className="col-span-2">
              <label className="block text-eyebrow text-fg-subtle tracking-wider mb-1.5">GPSLive Device</label>
              <select
                value={imei}
                onChange={e => setImei(e.target.value)}
                className="w-full h-11 px-3 rounded-card border border-admin-line bg-admin-surface text-[14px] text-admin-ink outline-none focus:border-admin-brand focus:bg-white transition"
              >
                <option value="">— Not assigned —</option>
                {/* If the currently-assigned imei isn't in today's live device list
                    (offline, or GPSLive briefly unreachable), keep it selectable so
                    saving the form without touching this field doesn't silently
                    clear a real assignment. */}
                {imei && !devices.some(d => d.imei === imei) && (
                  <option value={imei}>{imei} (not currently reporting)</option>
                )}
                {devices.map(d => (
                  <option key={d.imei} value={d.imei}>
                    {d.plateNumber || d.name} {d.plateNumber && d.name !== d.plateNumber ? `(${d.name})` : ""}
                  </option>
                ))}
              </select>
              <span className="text-[11px] text-admin-muted mt-1 block">
                Which live GPSLive tracker is this driver's usual van -- picked from the fleet, not typed, so it can't be mistyped.
              </span>
            </div>

            <div className="col-span-2">
              <label className="block text-eyebrow text-fg-subtle tracking-wider mb-1.5">
                Email Address <span className="text-admin-status-red">*</span>
              </label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full h-11 px-3 rounded-card border border-admin-line bg-admin-surface text-[14px] text-admin-ink outline-none focus:border-admin-brand focus:bg-white transition"
                placeholder="driver@example.com"
              />
              <span className="text-[11px] text-admin-muted mt-1 block">Used to sign the driver into the app, and as the unique key for this record.</span>
            </div>

            <div className="col-span-2">
              <label className="block text-eyebrow text-fg-subtle tracking-wider mb-1.5">Phone Number</label>
              <input
                type="tel"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                className="w-full h-11 px-3 rounded-card border border-admin-line bg-admin-surface text-[14px] text-admin-ink outline-none focus:border-admin-brand focus:bg-white transition"
                placeholder="07..."
              />
            </div>

            <div className="col-span-2">
              <label className="block text-eyebrow text-fg-subtle tracking-wider mb-1.5">
                Driver App Password
              </label>
              <input
                type="password"
                value={pwaPassword}
                onChange={e => setPwaPassword(e.target.value)}
                className={`w-full h-11 px-3 rounded-card border ${passwordTooShort ? 'border-admin-status-red focus:border-admin-status-red' : 'border-admin-line focus:border-admin-brand'} bg-admin-surface text-[14px] text-admin-ink outline-none focus:bg-white transition`}
                placeholder={driverToEdit ? "Leave blank to keep current password" : "Set a password (min 8 characters)"}
                autoComplete="new-password"
              />
              {passwordTooShort ? (
                <span className="text-[11px] text-admin-status-red mt-1 block">Must be at least 8 characters.</span>
              ) : (
                <span className="text-[11px] text-admin-muted mt-1 block">
                  Login for the driver mobile app.
                  {driverToEdit ? " Leave blank to keep their current password unchanged." : ""}
                </span>
              )}
            </div>

            <div className="col-span-2 mt-4 pt-4 border-t border-admin-line">
              <label className="block text-eyebrow text-fg-subtle tracking-wider mb-3">System Access & Status</label>
              <div className={`p-4 rounded-card border transition-colors ${active ? 'bg-admin-status-green-bg border-admin-status-green/20' : 'bg-[#FEF2F2] border-[#FECACA]'}`}>
                 <label className="flex items-start gap-3 cursor-pointer">
                   <div className="pt-0.5">
                     <input 
                       type="checkbox" 
                       checked={active}
                       onChange={(e) => setActive(e.target.checked)}
                       className="w-5 h-5 text-admin-brand rounded focus:ring-admin-brand"
                     />
                   </div>
                   <div>
                     <span className={`text-[14px] font-bold block ${active ? 'text-admin-status-green' : 'text-admin-status-red'}`}>
                       {active ? 'Active (App Access Enabled)' : 'Deactivated (Access Revoked)'}
                     </span>
                     <p className={`text-[13px] mt-1 ${active ? 'text-admin-status-green/80' : 'text-admin-status-red/80'}`}>
                       {active
                         ? 'Driver can log in, view assignments, and complete jobs.'
                         : 'Driver is immediately blocked from the app. Future assignments are stopped.'}
                     </p>
                   </div>
                 </label>
              </div>
            </div>
          </div>
        </div>

        <div className="px-6 py-4 border-t border-admin-line bg-admin-surface shrink-0">
          {saveError && (
            <p className="text-[12px] text-admin-status-red font-medium mb-3 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 shrink-0" /> {saveError}
            </p>
          )}
          {saveWarning && (
            <p className="text-[12px] text-amber-700 font-medium mb-3 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 shrink-0" /> {saveWarning}
            </p>
          )}
          <div className="flex items-center justify-end gap-3">
            {saveWarning ? (
              <Button onClick={onClose} iconLeft={<CheckCircle2 />}>
                Done
              </Button>
            ) : (
              <>
                <Button variant="ghost" onClick={onClose} disabled={isSaving}>
                  Cancel
                </Button>
                <Button
                  onClick={handleSubmit}
                  loading={isSaving}
                  disabled={isCodeTaken || passwordTooShort || !name || !code || !email}
                >
                  {isSaving ? "Saving…" : driverToEdit ? "Save changes" : "Add driver"}
                </Button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
